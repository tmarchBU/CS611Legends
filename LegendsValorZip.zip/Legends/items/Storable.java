package items;

/*
File: Storable.java
Developer: Tristan Marchand
Email: tmarch@bu.edu
BU ID: U13495035
Last Edited: Tuesday, November 10, 2020

Description: Interface for a storable object. Used by inventory
*/

public interface Storable 
{
    
}
