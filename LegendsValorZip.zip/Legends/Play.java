import game.PlayLegends;

// Test Commit

/*
File: Play.java
Developer: Tristan Marchand
Email: tmarch@bu.edu
BU ID: U13495035
Last Edited: Tuesday, November 10, 2020

Description: Runs PlayLegends, which plays the game of Legends
*/

/*
Imported Libraries
*/
public class Play 
{
    public static void main(String args[])
    {
        PlayLegends.run();
    }
}